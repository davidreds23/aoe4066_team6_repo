%% homework2_refsol.m
% Reference Solution - Homework 2
 clear; clc; close all; 

%% -------------------------------------------
% Load mission inputs and addt'l funcs
load(fullfile('mission_inputs.mat'));

%% -------------------------------------------
% Main Execution
Wto_S_range = 10:.1:60;
constraintNames = {'MxMach', 'Cruise', 'MaxAlt', 'Drop'};
%, 'CmbtTm1', 'CmbtTm2', 'Ps'

% Create thrust loading table
[WP_table, W_Pto_takeoff] = hw2_createThrustLoadingTable(air, constraints, aero_constraints, thrust, Wto_S_range, constraintNames, TO);

% Solve for optimal W/S and T/W
[optimal_WS, min_WP] = hw2_solveOptimalPoint(WP_table, W_Pto_takeoff, Wto_S_range);

% Compute landing W/S limit
Wto_S_landing = hw2_landing_constraint(Landing);

% Plot full diagram
hw2_plotConstraintDiagram(Wto_S_range, WP_table, W_Pto_takeoff, Wto_S_landing, optimal_WS, min_WP, constraintNames, aero_constraints, TO, Landing);

% Display table in GUI
hw2_showResultTable(WP_table, constraintNames, Wto_S_range);

% For MATLAB grader only:
MaxMach = WP_table(1,:);
Cruise = WP_table(2,:);
MaxAlt = WP_table(3,:);
% CmbtTrn1 = TW_table(4,:);
% CmbtTrn2 = TW_table(5,:);
% Ps = TW_table(6,:);
Takeoff = W_Pto_takeoff;
Landing = Wto_S_landing;

%% Supporting Functions 
% -------------------------------------------------------------------------
% Master Equation
function W_Pto = hw2_computeWingLoading(constraints, air, aero_constraints, thrust, Wto_S, TO)
    beta = constraints.W_Wto; %constraints.W_Wto
    T_min = 6530;
    T_max = 20660;
    alpha = thrust.throttle_lapse; %thrust.throttle_lapse
    n = constraints.n;
    q = aero_constraints.atm.q;
    M = constraints.Mach;
    V = aero_constraints.atm.V;
    CD0 = TO.Takeoff.CD0;
    K1 = TO.Takeoff.k1;
    Ps = constraints.Ps;

    z = (n * beta) ./ q;
    induced = K1 .* (z.^2) .* Wto_S;
    linear_drag = CD0 ./ Wto_S;
    parasite = Ps ./ V;

   % T_Wto = (TOP)*density_ratio*CL_TO*(hp/W)
   T_Wto = (beta ./ alpha) .* (q ./ beta .* (linear_drag + induced) + parasite);
   % T_Wto = ((beta./alpha).*(((q./(beta.*Wto_S)).*((K1.*((n.*beta.*Wto_S)./q).^2)+CD0)))+(Ps./.8));
   %P_W = ((((q.*CD0)./Wto_S)+(((K1.*n.^2)/q).*Wto_S)).*(V./.8))+(Ps./.8);
   P_W = (T_Wto.*V) ./ (.8.*550);
   W_Pto = (1./P_W);
end

% Function: Create thrust loading table
function [WP_table, W_Pto_takeoff] = hw2_createThrustLoadingTable(air, constraints, aero_constraints, thrust, Wto_S_range, constraintNames, TO)
    num_constraints = length(constraintNames);
    WP_table = zeros(num_constraints, length(Wto_S_range));
    
    for i = 1:num_constraints
        name = constraintNames{i};
        WP_table(i, :) = hw2_computeWingLoading(constraints.(name), air, aero_constraints.(name), thrust.(name), Wto_S_range, TO);
    end
    
    W_Pto_takeoff = hw2_takeoff_constraint(Wto_S_range, TO);
end

% Function: Solve for optimal W/S and W/P
function [optimal_WS_WP, min_WP] = hw2_solveOptimalPoint(WP_table, W_Pto_takeoff, Wto_S_range)
    WP_required = max([WP_table; W_Pto_takeoff], [], 1);
    [min_WP, min_idx] = min(WP_required);
    optimal_WS_WP = Wto_S_range(min_idx);
end

% Takeoff Constraint
function W_Pto = hw2_takeoff_constraint(Wto_S, TO)
    g = 32.174;
    V_Vstall = TO.Takeoff.V_Vstall;
    V_speed = TO.Takeoff.V_speed;
    beta = TO.Takeoff.W_Wto;
    alpha = 1; %change AB_thrustlapse 
    rho = TO.Takeoff.air_density;
    CLmax = TO.Takeoff.CLmax;
    Distance = TO.Takeoff.Distance;
    CD0 = TO.Takeoff.CD0;
    mu = TO.Takeoff.mu;
    k = V_speed / V_Vstall;
    %k = 1.2;

    term1 = (k^2. * beta.^2 .* Wto_S) ./ (alpha.* rho.* CLmax.* g.* Distance);
    term2 = 0.72.* CD0./ (beta.* CLmax) + mu;
    T_Wto = term1 + term2;
    W_Pto = (1./T_Wto)*((.8*550)/(TO.Takeoff.V_speed*1.68781));
   
end

function W_S_land = hw2_landing_constraint(Landing)
    % Raymer 2nd Edition Eqn 5.10 - Landing distance constraint
    % This creates a VERTICAL line on the constraint diagram
    
    % Landing parameters
    S_land = Landing.Distance;        % Landing distance available [ft]
    rho = Landing.air_density;        % Air density [slugs/ft³]
    CLmax = Landing.CLmax;            % Max lift coefficient with flaps
    V_stall = Landing.V_stall;        % Stall speed [kts] or [ft/s]
    
    % Constants
    g = 32.174;                       % Gravity [ft/s²]
    
    % Convert stall speed to ft/s if in knots
    if V_stall < 100  % Assume it's in knots if less than 100
        V_stall_fts = V_stall * 1.688;  % Convert knots to ft/s
    else
        V_stall_fts = V_stall;          % Already in ft/s
    end
    
    % Raymer Eqn 5.10: W/S = (S_land * ρ * CLmax) / 1.69
    % W_S_land = (S_land * rho * CLmax) / 1.69;
    W_S_land = ((S_land - 800) .* CLmax) ./ 80;
    
    % Alternative more detailed equation:
     %W_S_land = (S_land * rho * CLmax * g) / (0.6 * (1.3 * V_stall_fts)^2);
end

%% Plotting Functions
% ------------------------------------------------------------------------
% Function: Plot constraint diagram
function hw2_plotConstraintDiagram(Wto_S_range, WP_table, W_Pto_takeoff, Wto_S_landing, optimal_WS, min_WP, constraintNames, aero_constraints, TO, Landing)
    figure('Name', 'Constraint Diagram'); hold on;
    colors = lines(length(constraintNames));
    
   

    for i = 1:length(constraintNames)
        plot(Wto_S_range, WP_table(i, :), 'LineWidth', 2, 'DisplayName', constraintNames{i}, 'Color', colors(i,:));
    end
    
    plot(Wto_S_range, W_Pto_takeoff, 'k-', 'LineWidth', 2, 'DisplayName', 'Takeoff');
    xline(Wto_S_landing, '--k', 'LineWidth', 2, 'DisplayName', 'Landing');

%     plot(optimal_WS, min_WP, 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'g', ...
%         'DisplayName', sprintf('Optimum (W/S=%.1f, W/P=%.2f)', optimal_WS, min_WP));

    xlabel('Wing Loading W/S [psf]', 'FontSize', 20);
    ylabel('Weight-to-Power Ratio lb/hp', 'FontSize', 20);
    title('Constraint Diagram with Optimal Design Point', 'FontSize', 35);
    legend('Location', 'northeastoutside', 'FontSize', 18);
    set(gca, 'FontSize', 18)
    grid on;

    idxCmbt = strcmp(constraintNames, 'Drop');

    if any(idxCmbt)

    % 1. Landing constraint gives W/S at intersection:
    WS_land = Wto_S_landing;   % scalar
    
    % 2. Interpolate CmbtTm1's curve at WS_land
    WP_cmbt_at_land = interp1(Wto_S_range, WP_table(idxCmbt,:), WS_land);
    

    end
    WP_all = [WP_table; W_Pto_takeoff];
WP_envelope = min(WP_all, [], 1);

% Clip shading to landing constraint
WS_max = Wto_S_landing;
mask = Wto_S_range <= WS_max;

WS_shade = Wto_S_range(mask);
WP_shade = WP_envelope(mask);

% Build a polygon: top = min envelope, bottom = 0
x_poly = [WS_shade, fliplr(WS_shade)];
y_poly = [WP_shade, zeros(size(WP_shade))];

% Draw feasible region shading (light green)
fill(x_poly, y_poly, [0.35 0.80 0.35], ...
     'FaceAlpha', 0.35, ...
     'EdgeColor', 'none', ...
     'DisplayName', 'Feasible Region');

    % Plot points
   plot(39.9, 14.134, 'ko', 'MarkerSize', 14, 'MarkerFaceColor', 'r', ...
     'DisplayName', 'AT-802F (W/S=39.9, W/P=14.13)');
    
    plot(WS_land, WP_cmbt_at_land, 'ko', ...
        'MarkerSize', 14, 'MarkerFaceColor', 'g', ...
        'DisplayName', sprintf('Optimum (W/S=%.1f, W/P=%.2f)', WS_land, WP_cmbt_at_land));
    
    plot(48.9523, 8.9945, 'ko', 'MarkerSize', 14, 'MarkerFaceColor', 'b', ...
     'DisplayName', 'Takeoff (MTOW) (W/S=48.95, W/P=8.99)');

    plot(37.0475, 6.807, 'ko', 'MarkerSize', 14, 'MarkerFaceColor', 'y', ...
     'DisplayName', 'Takeoff (No Payload) (W/S=37.05, W/P=6.81)');
end

% Function: Show results table as a GUI element
function hw2_showResultTable(WP_table, constraintNames, Wto_S_range)
    fig = figure('Name', 'T/W Table');
    uitable(fig, ...
        'Data', round(WP_table, 3), ...
        'ColumnName', compose('W/S = %d', Wto_S_range), ...
        'RowName', constraintNames, ...
        'Units', 'normalized', ...
        'Position', [0 0 1 1]);
end