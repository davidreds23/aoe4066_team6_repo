%% Stability Analysis
clear; clc; close all;
 
%% ---- Aerodynamic Moment Coefficients ------------------------------------
flight = {'Cruise' 'Takeoff'};
cm_alpha  =  [-1.2209 -1.1718];   % Pitch moment slope (1/rad)
cm0       =  [0.1393 0.1722];    % Pitch moment at zero alpha
cm_deltae =  [1.5414 1.5103];    % Pitch moment due to elevator deflection (1/rad)
 
%% ---- Flight Conditions --------------------------------------------------
rho = [0.0019 0.00237];                          % Air density [slugs/ft^3]
Mach = [0.28 0.13];
Vinf = Mach .* sqrt(1.4*287*(273.14+20)) * 3.28;  % Freestream speed [ft/s]
for s = 1:length(Vinf)
    W = [15553 25553];                 % Max takeoff weight [lbs]
    q = 0.5 * rho(s) * Vinf(s)^2;         % Dynamic pressure [lb/ft^2]
    S = 504;                           % Wing reference area [ft^2]
    CW = W ./ (q * S);                 % Required lift coefficient
     
    fprintf('=== Flight Condition ===\n');
    fprintf('Vinf = %.2f ft/s\n', Vinf(s));
    fprintf('q    = %.4f lb/ft^2\n', q);
    fprintf('CW   = %.4f  (required CL)\n\n', CW(1));
    fprintf('CW   = %.4f  (required CL)\n\n', CW(2));
     
    %% ---- Extract VSPAERO Data -----------------------------------------------
    filename = {'AseqData.csv' 'AseqDataTakeoff.csv'};
    dataCruise = AseqExtract(filename{s});
     
    alpha_data = dataCruise.alpha;   % AoA vector [deg]
    CL_data    = dataCruise.CLtot;   % Lift coefficient vector
     
    %% ---- Build CL Interpolant -----------------------------------------------
    % Use pchip for smooth, shape-preserving interpolation of VSPAERO data.
    % CL_interp(alpha_deg) returns CL at any alpha within the sweep range.
    CL_interp = @(a_deg) interp1(alpha_data, CL_data, a_deg, 'pchip');
     
    %% ---- Root-Finding: Trim Alpha -------------------------------------------
    % Find alpha_trim such that CL(alpha_trim) = CW
    % Residual: f(alpha) = CL(alpha) - CW = 0
    weight_labels = {'OEW', 'MTOW'};
     
    for i = 1:length(W) 
        residual_CL = @(a_deg) CL_interp(a_deg) - CW(i);
         
        % Bracket search: find a sign change in the residual
        alpha_range = linspace(min(alpha_data), max(alpha_data), 1000);
        res_vals    = arrayfun(residual_CL, alpha_range);
        sign_change = find(diff(sign(res_vals)) ~= 0);
         
        if isempty(sign_change)
            error(['CL = CW = %.4f has no solution in the sweep range [%.1f, %.1f] deg.\n' ...
                   'Check MTOW, rho, Vinf, or S.'], CW(i), min(alpha_data), max(alpha_data));
        end
         
        % Use the first sign-change bracket (lowest trim alpha)
        a_lo = alpha_range(sign_change(1));
        a_hi = alpha_range(sign_change(1) + 1);
        alpha_trim_deg = fzero(residual_CL, [a_lo, a_hi]);
         
        %% ---- Solve for Elevator Deflection at Trim ------------------------------
        % CM = 0:  cm0 + cm_alpha*(alpha_trim_rad) + cm_deltae*delta_e = 0
        % => delta_e = -(cm0 + cm_alpha*alpha_trim_rad) / cm_deltae
         
        alpha_trim_rad = alpha_trim_deg * (pi/180);
        delta_e_rad    = -(cm0(s) + cm_alpha(s) * alpha_trim_rad) / cm_deltae(s);
        delta_e_deg    = delta_e_rad * (180/pi);
         
        %% ---- Results ------------------------------------------------------------
        fprintf('=== Trim Solution: %s (W = %.0f lbs) ===\n', weight_labels{i}, W(i));
        fprintf('alpha_trim = %+.4f deg  (%+.6f rad)\n', alpha_trim_deg, alpha_trim_rad);
        fprintf('delta_e    = %+.4f deg  (%+.6f rad)\n', delta_e_deg,    delta_e_rad);
        fprintf('CL @ trim  = %.6f  (target CW = %.6f)\n', CL_interp(alpha_trim_deg), CW(i));
        fprintf('CM @ trim  = %.2e  (should be ~0)\n\n', ...
            cm0(s) + cm_alpha(s)*alpha_trim_rad + cm_deltae(s)*delta_e_rad);
     
        %% ---- Plot: CL vs Alpha with Trim Point ----------------------------------
        figure('Name', sprintf('%s: CL vs Alpha - %s', flight{s}, weight_labels{i}), 'NumberTitle', 'off');
        plot(alpha_data, CL_data, 'b-o', 'LineWidth', 1.5, 'MarkerSize', 4); hold on;
        yline(CW(i), 'r--', 'LineWidth', 1.2, 'DisplayName', sprintf('C_W = %.4f (%s)', CW(i), weight_labels{i}));
        plot(alpha_trim_deg, CW(i), 'rp', 'MarkerSize', 14, 'MarkerFaceColor', 'r', ...
            'DisplayName', sprintf('Trim: \\alpha = %.2f°', alpha_trim_deg));
        grid on;
        xlabel('Angle of Attack \alpha (deg)', 'FontSize', 12);
        ylabel('C_L', 'FontSize', 12);
        title(sprintf('%s: C_L vs AoA — %s (W = %.0f lbs)', flight{s}, weight_labels{i}, W(i)), 'FontSize', 13);
        legend('VSPAERO C_L', sprintf('Required C_W (%s)', weight_labels{i}), 'Trim Point', 'Location', 'northwest');
         
        %% ---- Plot: CM vs Alpha --------------------------------------------------
        % Show pitching moment as a function of alpha with delta_e fixed at trim
        alpha_plot_deg = linspace(min(alpha_data), max(alpha_data), 200);
        alpha_plot_rad = alpha_plot_deg * (pi/180);
        CM_plot = cm0(s) + cm_alpha(s)*alpha_plot_rad + cm_deltae(s)*delta_e_rad;
         
        figure('Name', sprintf('%s: CM vs Alpha - %s', flight{s}, weight_labels{i}), 'NumberTitle', 'off');
        plot(alpha_plot_deg, CM_plot, 'k-', 'LineWidth', 1.5); hold on;
        plot(alpha_trim_deg, 0, 'rp', 'MarkerSize', 14, 'MarkerFaceColor', 'r', ...
            'DisplayName', sprintf('Trim: \\alpha = %.2f°', alpha_trim_deg));
        yline(0, 'k--', 'LineWidth', 0.8);
        xline(alpha_trim_deg, 'r--', 'LineWidth', 0.8);
        grid on;
        xlabel('Angle of Attack \alpha (deg)', 'FontSize', 12);
        ylabel('C_M', 'FontSize', 12);
        title(sprintf('%s: C_M at \\delta_e = %.2f° — %s (W = %.0f lbs)', flight{s}, delta_e_deg, weight_labels{i}, W(i)), 'FontSize', 13);
        legend('C_M(\alpha)', 'Trim Point', 'Location', 'northeast');
    end
end