function data = AseqExtract(filename)
%% extract_vspaero_data.m
% Extracts Angle of Attack (Alpha) and total lift coefficient (CLtot)
% from a VSPAERO history CSV file (AseqData.csv).
%
% VSPAERO history CSV format:
%   - Each row begins with a variable name (e.g., "Alpha", "CLtot")
%   - Followed by comma-separated values, one per wake iteration
%   - The LAST column is the converged (final) result
%
% Outputs:
%   alpha   - Angle of attack vector [deg]
%   CLtot   - Total lift coefficient vector (converged, last wake iteration)
%   data    - Struct containing both arrays
 
 %% ---- Read file and extract rows ------------------------------------------
fid = fopen(filename, 'r');
if fid == -1
    error('Cannot open file: %s', filename);
end
 
alpha_vals = [];
CLtot_vals = [];
 
while ~feof(fid)
    line = strtrim(fgetl(fid));
    if isempty(line) || ~ischar(line)
        continue
    end
 
    % Split line into tokens
    tokens = strsplit(line, ',');
    varName = strtrim(tokens{1});
 
    % Parse numeric values (columns 2 onward)
    numericTokens = tokens(2:end);
    values = str2double(numericTokens);
    values = values(~isnan(values));   % drop any empty/non-numeric tokens
 
    if isempty(values)
        continue
    end
 
    % VSPAERO repeats the same Alpha value across all wake iterations,
    % so just take the first value.
    if strcmpi(varName, 'Alpha')
        alpha_vals(end+1) = values(1); %#ok<AGROW>
 
    % CLtot columns represent successive wake iterations;
    % the LAST column is the converged result.
    elseif strcmpi(varName, 'CLtot')
        CLtot_vals(end+1) = values(end); %#ok<AGROW>
    end
end
 
fclose(fid);
 
%% ---- Validate and align --------------------------------------------------
nAlpha = numel(alpha_vals);
nCL    = numel(CLtot_vals);
 
if nAlpha ~= nCL
    warning(['Number of Alpha rows (%d) does not match CLtot rows (%d). ' ...
             'Truncating to the shorter length.'], nAlpha, nCL);
    n = min(nAlpha, nCL);
    alpha_vals = alpha_vals(1:n);
    CLtot_vals = CLtot_vals(1:n);
end
 
% Column vectors
alpha = alpha_vals(1:end-1);
CLtot = CLtot_vals(1:end-1);
 
%% ---- Pack into struct ----------------------------------------------------
data.alpha = alpha;
data.CLtot = CLtot;
data.source = filename;
 
%% ---- Display summary -----------------------------------------------------
fprintf('\n=== VSPAERO Data Extraction Summary ===\n');
fprintf('File   : %s\n', filename);
fprintf('Points : %d\n', numel(alpha));
fprintf('Alpha  : %.1f deg  to  %.1f deg\n', min(alpha), max(alpha));
fprintf('CLtot  : %.4f  to  %.4f\n', min(CLtot), max(CLtot));
fprintf('=======================================\n\n');