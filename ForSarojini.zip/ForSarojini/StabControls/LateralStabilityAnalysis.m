%% Lateral-Directional Stability Analysis

% Based on AVD Topic 10: Lateral-Directional Dynamics (Etkin & Reid)

clc; clear; close all;

% Mass & Geometry
W    = 25553;           % Total weight [lb] (full fuel, full payload)
g    = 32.2;            % Gravity [ft/s^2]
m    = W / g;           % Mass [slugs]
S = 504;                % Wing reference area [ft^2]
b = 56;                 % Wing span [ft]
% Moments of Inertia (from your Iyy buildup / OpenVSP) 
% Ix  = 149784.036;     % Roll moment of inertia [slug*ft^2]  <-- FILL IN
% Iz  = 1107828.654;                % Yaw moment of inertia  [slug*ft^2]  <-- FILL IN
% Ixz = 199448.629;                % Product of inertia     [slug*ft^2]  <-- FILL IN (0 if principal axes)
Ix = 135812;       
Iz = 233090;     
% Ixz = -3000;  

% Ix = 149784.036;
% Iz = 1107428.654;
Ixz = 0;

% Flight Condition
rho = 0.0019;
theta0 = 0;             % Trim pitch angle [rad]               <-- FILL IN (0 for level flight)
Mach = 0.28; 
u0 = Mach .* sqrt(1.4*287*(273.14+20)) * 3.28;  % Freestream speed [ft/s]
q = 0.5 * rho * u0^2;         % Dynamic pressure [lb/ft^2]
  

% Stability Derivatives (from VSP Aero)
CY_beta = -1.1795;   % Side force due to sideslip
CY_p    = -0.6616;   % Side force due to roll rate
CY_r    =  0.7255;   % Side force due to yaw rate
CY_dr   = -0.5536;   % Side force due to rudder

Cl_beta = -0.2668;   % Dihedral effect (roll moment due to sideslip)
Cl_p    = -1.0359;   % Roll damping
Cl_r    =  0.2722;   % Roll moment due to yaw rate
Cl_da   =  0.2175;   % Roll moment due to aileron
Cl_dr   =  0;

Cn_beta =  0.2459;   % Weathercock stability (yaw moment due to sideslip)
Cn_p    =  0.02532;   % Yaw moment due to roll rate
Cn_r    = -0.2638;   % Yaw damping
% Cn_r = -0.59;
Cn_dr   =  0.1986;   % Yaw moment due to rudder

%Computing Dimensional stability derivatives

% --- Side Force Derivatives ---
Yv = q * S * CY_beta / u0;           % ft*lb/(ft/s)
Yp = q * S * b * CY_p / (2 * u0);    % ft*lb/(rad/s)
Yr = q * S * b * CY_r / (2 * u0);    % ft*lb/(rad/s)

% --- Rolling Moment Derivatives ---
Lv = q * S * b * Cl_beta / u0;       % ft*lb/(ft/s)
Lp = q * S * b^2 * Cl_p / (2 * u0);  % ft*lb/(rad/s)
Lr = q * S * b^2 * Cl_r / (2 * u0);  % ft*lb/(rad/s)
% --- Yawing Moment Derivatives ---
Nv = q * S * b * Cn_beta / u0;       % ft*lb/(ft/s)
Np = q * S * b^2 * Cn_p / (2 * u0);  % ft*lb/(rad/s)
Nr = q * S * b^2 * Cn_r / (2 * u0);  % ft*lb/(rad/s)

% Building the A matrix (Equation 2 from Topic 10 Notes)
%  Equation (2) from Topic 10 notes
%  State vector: x = [delta_v, delta_p, delta_r, delta_phi]
% =========================================================

xi = Ix*Iz - Ixz^2;    % Inertia coupling term

A = [ (1/m)*Yv,                         (1/m)*Yp,                         (1/m)*Yr - u0,        g*cos(theta0);
      (1/xi)*(Iz*Lv + Ixz*Nv),          (1/xi)*(Iz*Lp + Ixz*Np),         (1/xi)*(Iz*Lr + Ixz*Nr),    0;
      (1/xi)*(Ixz*Lv + Ix*Nv),          (1/xi)*(Ixz*Lp + Ix*Np),         (1/xi)*(Ixz*Lr + Ix*Nr),    0;
      0,                                 1,                                tan(theta0),           0 ];

fprintf('=== A Matrix ===\n');
disp(A);

%  EIGENVALUE ANALYSIS

eigenvalues = eig(A);

fprintf('=== Eigenvalues ===\n');
for i = 1:length(eigenvalues)
    if imag(eigenvalues(i)) == 0
        fprintf('  lambda_%d = %.4f  (real)\n', i, real(eigenvalues(i)));
    else
        fprintf('  lambda_%d = %.4f + %.4fi\n', i, real(eigenvalues(i)), imag(eigenvalues(i)));
    end
end

% --- Identify modes ---
% Sort: real eigenvalues -> spiral (slow) and roll (fast)
%       complex pair    -> Dutch roll
real_eigs = eigenvalues(imag(eigenvalues) == 0);
cplx_eigs = eigenvalues(imag(eigenvalues) ~= 0);

[~, idx] = sort(abs(real_eigs));  % sort by magnitude
lambda_spiral = real_eigs(idx(1));  % smallest magnitude = spiral
lambda_roll   = real_eigs(idx(2));  % largest magnitude  = roll

if ~isempty(cplx_eigs)
    lambda_dr = cplx_eigs(1);       % Dutch roll (take one of the pair)
end

% FLYING QUALITIES CHECK (Figure Figure 3 & 4 from Topic 10 notes
% (MIL-SPEC))

fprintf('\n=== Flying Qualities Check ===\n');

% --- Spiral Mode ---
fprintf('\n-- Spiral Mode --\n');
if real(lambda_spiral) < 0
    fprintf('  Stable (converging)\n');
    T_half = log(2) / abs(real(lambda_spiral));
    fprintf('  Time to halve: %.2f s\n', T_half);
else
    T_double = log(2) / real(lambda_spiral);
    fprintf('  UNSTABLE - Time to double: %.2f s\n', T_double);
    fprintf('  Requirement: T_double > 12 s (Level 1)\n');
    if T_double > 12
        fprintf('  STATUS: PASS (Level 1)\n');
    elseif T_double > 4
        fprintf('  STATUS: PASS (Level 3 minimum)\n');
    else
        fprintf('  STATUS: FAIL\n');
    end
end

% --- Roll Mode ---
fprintf('\n-- Roll Mode --\n');
tau_roll = 1 / abs(real(lambda_roll));
fprintf('  Time constant: %.2f s\n', tau_roll);
fprintf('  Requirement: tau < 1.0 s (Level 1, Class I/IV)\n');
if tau_roll < 1.0
    fprintf('  STATUS: PASS (Level 1)\n');
elseif tau_roll < 1.4
    fprintf('  STATUS: PASS (Level 2)\n');
else
    fprintf('  STATUS: FAIL\n');
end

% --- Dutch Roll Mode ---
fprintf('\n-- Dutch Roll Mode --\n');
if ~isempty(cplx_eigs)
    omega_dr = abs(lambda_dr);              % natural frequency
    zeta_dr  = -real(lambda_dr) / omega_dr; % damping ratio
    zeta_omega = zeta_dr * omega_dr;

    fprintf('  Natural frequency: %.4f rad/s\n', omega_dr);
    fprintf('  Damping ratio:     %.4f\n', zeta_dr);
    fprintf('  zeta*omega:        %.4f rad/s\n', zeta_omega);
    fprintf('  Requirements (Level 1, Class I/IV, Category A):\n');
    fprintf('    Min zeta     = 0.19\n');
    fprintf('    Min zeta*wn  = 0.35 rad/s\n');
    fprintf('    Min omega_n  = 1.0  rad/s\n');

    pass = (zeta_dr >= 0.19) && (zeta_omega >= 0.35) && (omega_dr >= 1.0);
    if pass
        fprintf('  STATUS: PASS (Level 1)\n');
    else
        fprintf('  STATUS: FAIL - check individual requirements above\n');
    end
else
    fprintf('  No complex eigenvalues found - check derivatives\n');
end

%% =========================================================
%  SECTION 6: APPROXIMATE MODE ESTIMATES (Etkin Section 9)
%  Use these as a sanity check against full eigenvalue results
% =========================================================

fprintf('\n=== Approximate Mode Estimates (Etkin approximations) ===\n');

% Spiral mode approximation
lambda_s_approx = (Lr*Nv - Lv*Nr) / (-Iz*Lv + (u0/g)*(Lv*Np - Lp*Nv));
fprintf('  Spiral approx:    lambda_s = %.4f  (full: %.4f)\n', lambda_s_approx, real(lambda_spiral));

% Roll mode approximation
lambda_r_approx = Lp / Ix;
fprintf('  Roll approx:      lambda_r = %.4f  (full: %.4f)\n', lambda_r_approx, real(lambda_roll));

% Dutch roll approximation
omega_dr_approx = sqrt( (1/(m*Iz))*(Yv*Nr - Nv*Yr) + (u0/Iz)*Nv );
zeta_dr_approx  = -(1/(2*omega_dr_approx)) * ((1/m)*Yv + (1/Iz)*Nr);
fprintf('  Dutch roll approx: omega_n = %.4f rad/s,  zeta = %.4f\n', omega_dr_approx, zeta_dr_approx);

%% =========================================================
%  SECTION 7: SPIRAL STABILITY CRITERION (Etkin eq. 9.7.6)
% =========================================================

fprintf('\n=== Spiral Stability Criterion (Etkin 9.7.6) ===\n');
spiral_criterion = Lv*Nr - Lr*Nv;
fprintf('  Cl_beta*Cn_r - Cl_r*Cn_beta = %.4f\n', spiral_criterion);
if spiral_criterion > 0
    fprintf('  STATUS: Spirally stable\n');
else
    fprintf('  STATUS: Spirally unstable (check time to double)\n');
end

%  TIME HISTORY SIMULATION
%  Simulates response to a 1 deg rudder pulse (5s on, 5s off)
%  matching Figure 5b style from the notes
% =========================================================

% Input matrix B (rudder column only, aileron set to 0)
% Fill in your control derivatives from VSPAero
Ydr  = q * S * CY_dr;
Ldr  = q * S * b * Cl_dr;   
Ndr  = q * S * b * Cn_dr;   

B_rudder = [ (1/m)*Ydr;
             (1/xi)*(Iz*Ldr + Ixz*Ndr);
             (1/xi)*(Ixz*Ldr + Ix*Ndr);
             0 ];

% Time vector
dt = 0.01;
t  = 0:dt:120;

% Rudder pulse input: 1 deg from t=5s to t=15s
delta_r_input = zeros(size(t));
delta_r_input(t >= 5 & t <= 15) = 1 * (pi/180);  % convert to radians

% Simulate using simple Euler integration
x = zeros(4, length(t));   % [delta_v; delta_p; delta_r; delta_phi]
for i = 1:length(t)-1
    x(:,i+1) = x(:,i) + dt * (A*x(:,i) + B_rudder*delta_r_input(i));
end

% Convert back to useful units
delta_v   = x(1,:);            % ft/s
delta_p   = x(2,:) * 180/pi;  % deg/s
delta_r   = x(3,:) * 180/pi;  % deg/s
delta_phi = x(4,:) * 180/pi;  % deg

%  PLOTS

% --- Plot 1: Eigenvalues on Complex Plane ---
figure('Name','Eigenvalue Plot','Position',[100 100 700 500]);
hold on; grid on;
xline(0, 'k--', 'LineWidth', 1);
yline(0, 'k-',  'LineWidth', 0.5);

% Shade stable (left) half plane
xlim_vals = [-2 0.5];
fill([xlim_vals(1) 0 0 xlim_vals(1)], [-3 -3 3 3], [0.9 0.95 1.0], ...
    'EdgeColor','none','FaceAlpha',0.4');

% Plot eigenvalues
plot(real(lambda_spiral), imag(lambda_spiral), 'bs', 'MarkerSize', 12, ...
    'MarkerFaceColor','b', 'DisplayName','Spiral mode');
plot(real(lambda_roll),   imag(lambda_roll),   'r^', 'MarkerSize', 12, ...
    'MarkerFaceColor','r', 'DisplayName','Roll mode');
if ~isempty(cplx_eigs)
    plot(real(cplx_eigs), imag(cplx_eigs), 'go', 'MarkerSize', 12, ...
        'MarkerFaceColor','g', 'DisplayName','Dutch roll mode');
end

xlabel('Real part, \sigma (s^{-1})');
ylabel('Imaginary part, \omega (rad/s)');
title('Lateral-Directional Eigenvalues');
legend('Location','northwest');
text(-1.5, 2.5, 'STABLE', 'FontSize', 14, 'Color', [0.2 0.4 0.8], 'FontWeight','bold');
text(0.1,  2.5, 'UNSTABLE', 'FontSize', 14, 'Color', [0.8 0.2 0.2], 'FontWeight','bold');
xlim(xlim_vals); ylim([-3 3]);

% --- Plot 2: Rudder Pulse Time History ---
figure('Name','Rudder Pulse Response','Position',[100 100 800 600]);

subplot(4,1,1);
plot(t, delta_v, 'b', 'LineWidth', 1.5); grid on;
ylabel('\Delta v (ft/s)'); 
title('Response to 1° Rudder Pulse');

subplot(4,1,2);
plot(t, delta_p, 'r', 'LineWidth', 1.5); grid on;
ylabel('\Delta p (deg/s)');
xline(5,'k--'); xline(15,'k--');

subplot(4,1,3);
plot(t, delta_r, 'g', 'LineWidth', 1.5); grid on;
ylabel('\Delta r (deg/s)');
xline(5,'k--'); xline(15,'k--');

subplot(4,1,4);
plot(t, delta_phi, 'm', 'LineWidth', 1.5); grid on;
ylabel('\Delta\phi (deg)');
xlabel('Time (s)');
xline(5,'k--'); xline(15,'k--');

% --- Plot 3: Spiral Mode Detail ---
figure('Name','Spiral Mode','Position',[100 100 700 350]);
t_spiral = 0:0.1:60;
if real(lambda_spiral) ~= 0
    spiral_response = exp(real(lambda_spiral) * t_spiral);
    plot(t_spiral, spiral_response, 'b', 'LineWidth', 2); grid on;
    yline(2, 'r--', 'LineWidth', 1.5, 'DisplayName', 'Double amplitude');
    yline(0.5,'g--','LineWidth', 1.5, 'DisplayName', 'Half amplitude');
    xlabel('Time (s)'); ylabel('Amplitude ratio');
    title('Spiral Mode Response (normalized)');
    legend('Location','best');
    if real(lambda_spiral) > 0
        xline(T_double, 'r:', 'LineWidth', 2, ...
            'Label', sprintf('T_{double} = %.1fs', T_double));
    end
end

fprintf('\n=== Done. Check figures and console output. ===\n');